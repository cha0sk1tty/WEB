print("-".join(input().split()))
