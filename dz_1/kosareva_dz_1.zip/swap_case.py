s = input()
if 0 < len(s) <= 1000:
    print(s.swapcase())
else:
    print("Строка должна содержать от 1 до 1000 символов.")
