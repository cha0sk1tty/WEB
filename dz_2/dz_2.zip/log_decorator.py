from datetime import datetime
import time


def function_logger(file_name):
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Время начала выполнения функции
            start_time = datetime.now()
            start_time_str = start_time.strftime("%Y-%m-%d %H:%M:%S")

            # Логируем название функции и время вызова
            with open(file_name, "a") as file:
                file.write(f"Функция: {func.__name__}\n")
                file.write(f"Время вызова: {start_time_str}\n")
                file.write(
                    f"Аргументы: позиционные аргументы={args}, ключевые аргументы={kwargs}\n"
                )

            # Выполняем функцию и получаем результат
            result = func(*args, **kwargs)

            # Время завершения выполнения функции
            end_time = datetime.now()
            end_time_str = end_time.strftime("%Y-%m-%d %H:%M:%S")

            # Время работы функции (в секундах)
            execution_time = (end_time - start_time).total_seconds()

            # Логируем результат, время завершения и время работы
            with open(file_name, "a") as file:
                file.write(
                    f"Возвращаемое значение: {result if result is not None else '-'}\n"
                )
                file.write(f"Время завершения работы функции: {end_time_str}\n")
                file.write(f"Время работы функции: {execution_time:.6f} seconds\n")
                file.write("-" * 40 + "\n")  # Разделитель для удобства чтения
            return result
        return wrapper
    return decorator


@function_logger("test.log")
def greeting_format(name):
    return f"Hello, {name}!"

# Пример вызова функции
greeting_format("John")
greeting_format("Alice")
