def sum_and_sub(a: int, b: int) -> str:
    return a + b, a - b


if __name__ == "__main__":
    print(sum_and_sub(2, 3))
    print(sum_and_sub(6, 10))
    print(sum_and_sub(51, 3))
    print(sum_and_sub(11, 22))
