import os
import sys

def search_file(filename):
    current_dir = os.getcwd()
    output = []

    for root, _, files in os.walk(current_dir):
        if filename in files:
            file_path = os.path.join(root, filename)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    lines = []
                    for _ in range(5):
                        line = f.readline()
                        if not line:
                            break
                        lines.append(line.strip())
                    # Формируем строку с выводом
                    output.append(f"\nФайл расположен в: {root}")
                    output.append("\nДанные файла (5 строк):")
                    output.append("\n".join(lines))
                    return "\n".join(output)  # Возвращаем результат как строку
            except Exception as e:
                output.append(f"\nФайл расположен: {root}")
                output.append(f"Ошибка при чтении: {str(e)}")
                return "\n".join(output)
    
    return f"Файл {filename} не найден"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python file_search.py <имя_файла>", file=sys.stderr)
        sys.exit(1)
    
    filename = sys.argv[1]
    result = search_file(filename)
    print(result)