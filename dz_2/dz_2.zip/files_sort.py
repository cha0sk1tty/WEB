import os
import sys

def list_files_by_extension(directory):
    items = os.listdir(directory)
    files = [item for item in items if os.path.isfile(os.path.join(directory, item))]
    files.sort(key=lambda x: (os.path.splitext(x)[1], x))  # Сортировка по расширению и имени
    return files 

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python files_sort.py <директория>")
    else:
        directory = sys.argv[1]
        if os.path.isdir(directory):
            sorted_files = list_files_by_extension(directory)
            for file in sorted_files:
                print(file)
        else:
            print(f"Ошибка: '{directory}' не является директорией.")