def compute_average_scores(scores: list) -> list:
    # Проверяем формат входных данных
    if isinstance(scores[0], str):
        # пропускаем первый элемент 'n x', преобразуем строки в числа
        scores_list = [list(map(float, s.split())) for s in scores[1:]]
    else:
        # преобразуем кортежи в списки
        scores_list = [list(score) for score in scores]
    
    n = len(scores_list[0])
    scores_one_people = [0.0] * n
    for score in scores_list:
        for i in range(n):
            scores_one_people[i] += score[i]
    average_scores = [round(total / len(scores_list), 1) for total in scores_one_people]
    return average_scores

if __name__ == "__main__":
    n, x = map(int, input().split())
    if 0 < n <= 100 and 0 < x <= 100:
        scores = []
        for _ in range(x):
            scores.append(tuple(map(float, input().split())))
        average_scores = compute_average_scores(scores)

        for avg in average_scores:
            print(f"{avg:.1f}")

    else:
        print("Значения x и n должны быть в диапазоне от 0 до 100 включительно.")
