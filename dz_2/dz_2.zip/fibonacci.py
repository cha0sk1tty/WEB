
def fibonacci(n):
    fibonacci_list = []
    a, b = 0, 1
    for _ in range(n):
        fibonacci_list.append(a**3)
        a, b = b, a + b
    return fibonacci_list
 

if __name__ == "__main__":
    n = int(input())
    if 1 <= n <= 15:
        print(list(fibonacci(n)))
    else:
        print("n должно быть в диапазоне от 1 до 15.")

